/******************************************
    Version: 1.0
/****************************************** */

(function($) {
    "use strict";

    /* ==============================================
    Fixed menu
    =============================================== */
    
	$(window).on('scroll', function () {
		if ($(window).scrollTop() > 50) {
			$('.header_style_01').addClass('fixed-menu');
		} else {
			$('.header_style_01').removeClass('fixed-menu');
		}
	});	
	
	/* ==============================================
		Scroll to top  
	============================================== */
		
	if ($('#scroll-to-top').length) {
		var scrollTrigger = 100, // px
			backToTop = function () {
				var scrollTop = $(window).scrollTop();
				if (scrollTop > scrollTrigger) {
					$('#scroll-to-top').addClass('show');
				} else {
					$('#scroll-to-top').removeClass('show');
				}
			};
		backToTop();
		$(window).on('scroll', function () {
			backToTop();
		});
		$('#scroll-to-top').on('click', function (e) {
			e.preventDefault();
			$('html,body').animate({
				scrollTop: 0
			}, 700);
		});
	}
	
    /* ==============================================
       LOADER -->
        =============================================== */

    $(window).load(function() {
        $("#preloader").on(500).fadeOut();
        $(".preloader").on(600).fadeOut("slow");
    });

    /* ==============================================
     FUN FACTS -->
     =============================================== */

    function count($this) {
        var current = parseInt($this.html(), 10);
        current = current + 50; /* Where 50 is increment */
        $this.html(++current);
        if (current > $this.data('count')) {
            $this.html($this.data('count'));
        } else {
            setTimeout(function() {
                count($this)
            }, 30);
        }
    }
    $(".stat_count, .stat_count_download").each(function() {
        $(this).data('count', parseInt($(this).html(), 10));
        $(this).html('0');
        count($(this));
    });

    /* ==============================================
     TOOLTIP -->
     =============================================== */
    $('[data-toggle="tooltip"]').tooltip()
    $('[data-toggle="popover"]').popover()

    /* ==============================================
     CONTACT -->
     =============================================== */
    jQuery(document).ready(function() {
        $('#contactform').submit(function() {
            var action = $(this).attr('action');
            $("#message").slideUp(750, function() {
                $('#message').hide();
                $('#submit')
                    .after('<img src="images/ajax-loader.gif" class="loader" />')
                    .attr('disabled', 'disabled');
                $.post(action, {
                        first_name: $('#first_name').val(),
                        last_name: $('#last_name').val(),
                        email: $('#email').val(),
                        phone: $('#phone').val(),
                        select_service: $('#select_service').val(),
                        select_price: $('#select_price').val(),
                        comments: $('#comments').val(),
                        verify: $('#verify').val()
                    },
                    function(data) {
                        document.getElementById('message').innerHTML = data;
                        $('#message').slideDown('slow');
                        $('#contactform img.loader').fadeOut('slow', function() {
                            $(this).remove()
                        });
                        $('#submit').removeAttr('disabled');
                        if (data.match('success') != null) $('#contactform').slideUp('slow');
                    }
                );
            });
            return false;
        });
    });

    /* ==============================================
     CODE WRAPPER -->
     =============================================== */

    $('.code-wrapper').on("mousemove", function(e) {
        var offsets = $(this).offset();
        var fullWidth = $(this).width();
        var mouseX = e.pageX - offsets.left;

        if (mouseX < 0) {
            mouseX = 0;
        } else if (mouseX > fullWidth) {
            mouseX = fullWidth
        }

        $(this).parent().find('.divider-bar').css({
            left: mouseX,
            transition: 'none'
        });
        $(this).find('.design-wrapper').css({
            transform: 'translateX(' + (mouseX) + 'px)',
            transition: 'none'
        });
        $(this).find('.design-image').css({
            transform: 'translateX(' + (-1 * mouseX) + 'px)',
            transition: 'none'
        });
    });
    $('.divider-wrapper').on("mouseleave", function() {
        $(this).parent().find('.divider-bar').css({
            left: '50%',
            transition: 'all .3s'
        });
        $(this).find('.design-wrapper').css({
            transform: 'translateX(50%)',
            transition: 'all .3s'
        });
        $(this).find('.design-image').css({
            transform: 'translateX(-50%)',
            transition: 'all .3s'
        });
    });

})(jQuery);

$(document).ready(function () {
    $(".top-feature").owlCarousel({
      items: 4,
      loop: true,
      navigation: true,
      navigationText: ["", ""],
      pagination: true,
      autoplay: true, // Automatically start the carousel
      autoplayTimeout: 3000, // Time between transitions (3 seconds)
      responsive: {
        0: {
          items: 1, // 1 item for screen widths of 0-600px
        },
        0: {
          items: 2, // 1 item for screen widths of 0-600px
        },
        0: {
          items: 3, // 1 item for screen widths of 0-600px
        },
        0: {
          items: 4, // 1 item for screen widths of 0-600px
        },
        
        
      },
    });
  });
  


$(document).ready(function() {
    // Call the function to show and hide the modal automatically
    callshowpopup();
});

var modalInterval;

function callshowpopup() {
    // Clear any previously running interval to prevent multiple intervals stacking up
    if (modalInterval) {
        clearInterval(modalInterval);
    }

    // Set an interval to open and close the modal every 10 seconds (3 seconds to show + 7 seconds to hide)
    modalInterval = setInterval(function() {
        // Show the modal after 3 seconds
        $('#exampleModal').modal('show');
        
        // Hide the modal after 7 seconds (increase this time)
        // setTimeout(function() {
        //     $('#exampleModal').modal('hide');
        // }, 9000); 
        
    }, 5000); // Repeats every 10 seconds (3 seconds to show + 7 seconds to hide)
}

$(document).ready(function () {
    $('#submitBtn').click(function () {
        // Collect form data
        var name = $('#Name').val();
        var number = $('#Number').val();
        var email = $('#Email').val();
        var project = $("input[name='Project']").val();

        // Form data object
        var formData = {
            Name: name,
            Number: number,
            Email: email,
            Project: project,
            submit: true
        };

        // Log form data to console
        console.log("Form Data:", formData);

        // Send data via AJAX
        $.ajax({
            url: 'contact_form.php', // Backend PHP file
            type: 'POST',
            data: formData,
            success: function (response) {
                console.log("Server Response:", response);
                alert('Thank you for your submission!');
                window.location.href = "thanks.php"; // Redirect to thank you page
            },
            error: function (xhr, status, error) {
                console.error("Error:", status, error);
                alert('There was an error submitting your form. Please try again.');
            }
        });
    });
});

