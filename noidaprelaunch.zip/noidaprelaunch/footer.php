<div class="footer">
        <div class="row">
            <h1 class="text-center" style="color:#ffffff;">Contact-Details</h1>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <p style="margin-left:10px;">info@noidaprelaunch.com</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <p>Office: C-7, Sai Chowk, Madhu Vihar, Patparganj, New Delhi- 110092</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <p>Branch Office: Unit No. 1146, Supernova Astralis, Sector- 94, Noida, Uttar Pradesh- 201301</p>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <p>+91 9599040403</p>
            </div>
        </div>
        <div class="privacy">
            <div class="row">
                <p class="text-center"><a href="privacy policy.php"><span style="color:#fff;">Privacy Policy</sapn>
                            </a><a href="privacy policy.php"><span style="color:#fff;"> & Disclaimer</p>
                </sapn></a>
                <p class="text-center">Agent RERA Registration- UPRERAAGT21785</p>

            </div>
        </div>
    
</footer>
    </body>
</html>