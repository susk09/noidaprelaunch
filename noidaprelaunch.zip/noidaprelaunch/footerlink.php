<!-- ALL JS FILES -->
<script src="js/all.js"></script>
<!-- ALL PLUGINS -->
<script src="js/custom.js"></script>
<script src="js/portfolio.js"></script>
<script src="js/hoverdir.js"></script>
<!-- <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script> -->
<!-- MAP & CONTACT -->
<script src="js/map.js"></script>
<script src="js/animate.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/owl.scroll.min.js"></script>