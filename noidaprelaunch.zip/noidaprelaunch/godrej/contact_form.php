<?php

$con = new mysqli('localhost', 'root', '', 'upcoming');
if ($con->connect_error) {
    die("Failed to connect to MySQL: " . $con->connect_error);
}

// Check if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['number']);
    $project = htmlspecialchars($_POST['project']);

    // Validate email
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

        // Email details
        $to = "digimarketing936@gmail.com, noidaluxury@gmail.com"; // Replace with your email
        $subject = "New Contact Form Submission";
        $headers = "From: $email" . "\r\n" . 
                   "Reply-To: $email" . "\r\n" .
                   "Content-Type: text/html; charset=UTF-8";

        // Message body
        $message = "
        <html>
        <head>
            <title>Contact Form Submission</title>
        </head>
        <body>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Phone:</strong> $phone</p>
            <p><strong>Project:</strong> $project</p>
        </body>
        </html>";

        // Send email
        if (mail($to, $subject, $message, $headers)) {
            echo "Email sent successfully.";
        } else {
            echo "Error sending email.";
        }
    } else {
        echo "Invalid email address.";
        exit();
    }

    // Insert into the database
    $stmt = $con->prepare("INSERT INTO form (name, phone, email, project) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("ssss", $name, $phone, $email, $project);
        if ($stmt->execute()) {
            echo "Data saved successfully.";
        } else {
            echo "Failed to save data.";
        }
        $stmt->close();
    } else {
        echo "Failed to prepare the database statement.";
    }
}

// Close the database connection
$con->close();
?>
