<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Site Metas -->
    <title>Noida Luxury: Exclusive Offers on Upcoming Luxury Real Estate Deals</title>

    <style>
    table {
    width: 600px;
    height: 300px;
    border: 8px solid #C18F2D;
    font: bold 20px Verdana, Arial, Helvetica, sans-serif;
    color: #000000;
    margin: 130px auto 0 auto;
    text-align: center;
    font-style: italic;
    border-radius:5px;
}
    </style>
</head>

<body>
<table width="600" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
    <td>Thanks for contacting us.<br><br>
We shall get back to you shortly.</td>
  </tr>
</tbody>
</table>

</body>

</html>