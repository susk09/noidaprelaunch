<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>

    <?php include "header.php"; ?>
    <?php include "headerlink.php"; ?>

</head>
<style>
    .container {
        background-color: #f9f9f9;
        border-radius: 20px;
        box-shadow: 10px;
        /* border:1px solid red; */
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
</style>

<body>
    <div class="container" style="margin-top:80px;">
        <div class="row">
            <h1 class="text-center">HOME</h1>
            <h2 style="font-weight:bold;">Privacy Policy</h2>
            <p><span style="font-weight:bold;">Noidaprelaunch.com</span> is a comprehensive real estate consultancy
                platform, primarily focused on marketing real estate projects, developer property transactions, and
                investment advisory. This Privacy Policy outlines how we collect, use, and safeguard your personal
                information when you use our services. By accessing noidaprelaunch.com, you agree to the terms of this
                Privacy Policy and the accompanying Terms of Use.
                We respect and prioritize your privacy, ensuring that all personal data we collect is treated with the
                highest confidentiality. This Privacy Policy details how we handle your information and the choices you
                have regarding the use of your data.
            </p>

            <p>We respect and prioritize your privacy, ensuring that all personal data we collect is treated with the
                highest confidentiality. This Privacy Policy details how we handle your information and the choices you
                have regarding the use of your data.</p>
        </div>

        <h1>1. GENERAL</h1>
        <p><span style="font-weight:bold;">•a)</span> This document complies with the provisions of the Information
            Technology Act, 2000, and the rules related to electronic records and their amendments. This Privacy Policy
            forms an electronic record and does not require physical or digital signatures.</p>
        <p><span style="font-weight:bold;">•b)</span> Published in accordance with Rule 3 (1) of the Information
            Technology (Intermediary Guidelines) Rules, 2011, this policy outlines the rules and regulations, privacy
            policies, and Terms of Use for noidaprelaunch.com.</p>
        <p><span style="font-weight:bold;">•c)</span> The domain name https://noidaprelaunch.com is owned and operated
            by Greystone Construction, located at C-7, Sai Chowk, Madhu Vihar, Patparganj, Delhi- 110092. This Privacy
            Policy becomes effective when you provide personal information or interact with the platform.</p>
        <h1>2. COLLECTION OF PERSONAL AND OTHER INFORMATION</h1>
        <p><span style="font-weight:bold;">a)</span> To enhance your experience on noidaprelaunch.com, we may collect
            personal data such as your name, contact details, and preferences. Additionally, you may be required to
            register on our platform and provide relevant information.</p>

        <p><span style="font-weight:bold;">b)</span> By using our services, you consent to our tracking of certain user
            data, such as your IP address and browser activity. This data helps us understand our audience better and
            improve your experience. We also collect information like the URL you visited before accessing our website
            and the URLs you visit afterward.</p>

        <p><span style="font-weight:bold;">c)</span> You may be asked to provide feedback or reviews of services or
            products offered on our platform. These reviews help us improve and may be displayed publicly with your name
            for the benefit of other users.</p>

        <h1>3. COOKIES</h1>
        <p><span style="font-weight:bold;">a)</span> Like most websites, noidaprelaunch.com uses cookies to enhance your
            browsing experience. Cookies store small pieces of information that help us remember your login details and
            customize your interactions with the website.</p>

        <p><span style="font-weight:bold;">b)</span> We use cookies to analyze site traffic, monitor the effectiveness
            of marketing campaigns, and enhance trust and security. While you are free to disable cookies via your
            browser settings, doing so may limit some functionality of our services.</p>


        <h1>4. SHARING OF PERSONAL INFORMATION</h1>
        <p><span style="font-weight:bold;">a)</span> noidaprelaunch.com may share your personal data with affiliated
            entities for purposes such as fraud detection, law compliance, or collaborative services.</p>

        <p><span style="font-weight:bold;">b)</span> We may disclose personal information when required by law or when
            necessary to protect the legal rights of noidaprelaunch.com, our users, or the public. This includes
            responding
            to legal processes such as subpoenas and protecting the safety of our users.</p>

        <h1>5. SECURITY</h1>
        <p>We take appropriate security measures to protect your personal data from unauthorized access or disclosure.
            All
            transactions on noidaprelaunch.com are encrypted, ensuring that sensitive information such as payment
            details
            remains confidential.</p>

        <h1>DISPUTE RESOLUTION AND JURISDICTION</h1>
        <p><span style="font-weight:bold;">a)</span> Mediation: In case of any disputes, both parties will first attempt
            to
            resolve the issue amicably. If no resolution is reached within 30 days, the matter will proceed to
            arbitration.
        </p>

        <p><span style="font-weight:bold;">b)</span> Arbitration: Disputes unresolved through mediation will be referred
            to
            arbitration under a sole arbitrator appointed by noidaprelaunch.com. The seat of arbitration will be [insert
            preferred city], and the proceedings will be conducted in English.</p>
        <p>The courts at Noida, Gautam Budh Nagar shall have jurisdiction over all matters arising from the use of this
            platform.</p>
        <br>
        <h2 style="font-weight:bold;">Disclaimer</h2>

        <p>Disclaimer The content provided on this website is for information purposes only and does not constitute an offer to avail any service. The prices mentioned are subject to change without prior notice, and the availability of properties mentioned is not guaranteed. The images displayed on the website are for representation purposes only and may not reflect the actual properties accurately.</p>

        <p>Please note that this is the official website of an authorized marketing partner Invest bloom. We may share data with Real Estate Regulatory Authority (RERA) registered brokers/companies for further processing as required. We may also send updates and information to the mobile number or email ID registered with us. All rights reserved. The content, design, and information on this website are protected by copyright and other intellectual property rights. Any unauthorized use or reproduction of the content may violate applicable laws. For accurate and up-to-date information regarding services, pricing, availability, and any other details, it is advisable to contact us directly through the provided contact information on this website. Thank you for visiting our website.</p>
    </div>
    </div>

    <?php include "footer.php"; ?>
    <?php include "footerlink.php"; ?>

</body>

</html>