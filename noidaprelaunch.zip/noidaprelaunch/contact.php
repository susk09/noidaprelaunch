<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Site Metas -->
    <title>Noida Luxury: Exclusive Offers on Upcoming Luxury Real Estate Deals</title>
    <?php include "headerlink.php"; ?>
   
</head>
<?php include "header.php"; ?>
<body>
<div class="section">
    <div class="row">
        <img src="images/contact.jpeg" style="width:100%; ">
    </div>
</section>
</body>

<?php include "footer.php"; ?>
<?php include "footerlink.php"; ?>

</body>
</html>