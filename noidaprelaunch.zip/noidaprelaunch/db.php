
<?php

$con = new mysqli('localhost', 'u531888297_form', 'Indi@9091', 'u531888297_upcoming');
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

?>