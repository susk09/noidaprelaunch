<!DOCTYPE html>
<html lang="en">

<head>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W7VDZ2BL');</script>
<!-- End Google Tag Manager -->

    <title>Noida Prelaunch</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <!-- <span class="loader"><span class="loader-inner"></span></span> -->
    </div> <!-- end loader -->
    <!-- END LOADER -->

    <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="images/logo.jpeg" alt="image" width="76px" height="60px"></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="active" href="index.html">Home</a></li>
                        <li><a href="about.html">About us </a></li>
                        <li><a href="service.html">Project</a></li>
                        <li><a href="gallery.html">Blogs</a></li>
                        <li><a href="properties.html">Listing</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="https://in.pinterest.com/noidaluxury"><i class="fa fa-pinterest global-radius"></i></a></li>
                        <li class="social-links"><a href="https://www.facebook.com/luxurynoida"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="https://www.instagram.com/noidaluxury/"><i class="fa fa-instagram global-radius"></i></a></li>
						<!-- <li class="search-option">
							<button class="search tran3s dropdown-toggle" id="searchDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search" aria-hidden="true"></i></button>
							<form action="#" class="p-color-bg dropdown-menu tran3s" aria-labelledby="searchDropdown">
								<input type="text" placeholder="Search....">
								<button class="p-color-bg"><i class="fa fa-search" aria-hidden="true"></i></button>
							</form>
					   </li>  -->
                    </ul>
                </div>
            </div>
        </nav>
    </header>
</body>
</html>